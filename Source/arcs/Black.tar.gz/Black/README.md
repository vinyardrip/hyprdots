<div align = center><img src="https://raw.githubusercontent.com/prasanthrangan/hyprdots/main/Source/assets/hyprdots_banner.png"><br><br></div>


> [!IMPORTANT]
> WORK IN PROGRESS...


https://github.com/prasanthrangan/hyprdots-mod/assets/106020512/0c7f12a8-11f2-4a16-890e-44f07a860636


> [!NOTE]
> This is not a standalone theme, needs [Hyprdots](https://github.com/prasanthrangan/hyprdots) installed...

